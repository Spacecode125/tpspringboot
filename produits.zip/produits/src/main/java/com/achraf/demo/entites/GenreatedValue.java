package com.achraf.demo.entites;

public @interface GenreatedValue {

}
