package com.achraf.demo.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import com.achraf.demo.entites.Produit;

public interface ProduitsRepository extends JpaRepository<Produit, Long> {
	

}
