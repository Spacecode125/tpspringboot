package com.achraf.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.achraf.demo.entites.Produit;
import com.achraf.demo.repos.ProduitsRepository;

@Service
public class ProduitServiceimpl implements ProduitService {
	
	@Autowired
	ProduitsRepository  produitRepository;  

	@Override
	public Produit saveProduit(Produit p) {
		
		return  produitRepository.save(p);
	}

	@Override
	public Produit updateProduit(Produit p) {
		return  produitRepository.save(p);	
	}

	@Override
	public void deleteProduit(Produit p) {
		 produitRepository.delete(p);
		
	}

	@Override
	public void deleteProduitById(Long id) {
		produitRepository.deleteById(id);
		
	}

	@Override
	public Produit getProduit(Long id) {
		
		return  produitRepository.findById(id).get();
	}

	@Override
	public List<Produit> getAllProduits() {
		
		return produitRepository.findAll();
	}

}
