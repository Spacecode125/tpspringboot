package com.achraf.demo;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.Date;
import java.util.List;

import com.achraf.demo.entites.Produit;
import com.achraf.demo.repos.ProduitsRepository;


@SpringBootTest
class ProduitsApplicationTests {
		
		@Autowired
		private ProduitsRepository produitRepository;
		
		@Test
		public void testCreateProduit() {
		Produit prod = new Produit("PC Asuss",1500.500,new Date());
		produitRepository.save(prod);
		
		}
		
		@Test
		public void testFindProduit()
		{
		Produit p = produitRepository.findById(1L).get();

		System.out.println(p);
		}
		
		
	
		@Test
		public void testUpdateProduit()
		{
		Produit p = produitRepository.findById(2L).get();
		p.setPrixProduit(300.0);
		produitRepository.save(p);

		System.out.println(p);
		}
		
		
		@Test
		public void testDeleteProduit()
		{
			produitRepository.deleteById(3L);;
		}
		
		@Test
		public void testFindAllProduits()
		{
			List<Produit> prods = produitRepository.findAll();
			for (Produit p:prods)
				System.out.println(p);
			
		}
		

}
